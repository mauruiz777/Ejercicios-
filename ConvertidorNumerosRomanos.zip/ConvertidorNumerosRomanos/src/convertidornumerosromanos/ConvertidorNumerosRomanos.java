/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package convertidornumerosromanos;

import java.util.Scanner;

/**
 *
 * @author MauricioRJ
 */
public class ConvertidorNumerosRomanos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int numero = 0;

        do {

            System.out.println("Ingresa Solo numeros del 1 al 1000:");
            Scanner entrada = new Scanner(System.in);
            numero = entrada.nextInt();
            if (numero <= 1000 && numero >= 1) {
                System.out.println(convertidor(numero));
            }
            
        } while (numero > 1000 || numero < 1);

        //     int  unidades = numero % 10;
//      System.out.println(unidades);
    }

    public static String convertidor(int numero) {
        int millares, centenas, decenas, unidades;
        String salida = "";

        unidades = numero % 10;
        decenas = numero / 10 % 10;
        centenas = numero / 100 % 10;
        millares = numero / 1000;

        if (unidades == 9) {
            salida = salida + "IX";
        } else if (unidades >= 5) {
            salida = salida + "V";
            for (int i = 6; i <= unidades; i++) {
                salida = salida + "I";
            }
        } else if (unidades == 4) {
            salida = salida + "IV";
        } else {
            for (int i = 1; i <= unidades; i++) {
                salida = salida + "I";
            }
        }

        if (decenas == 9) {
            salida = salida + "XC";
        } else if (decenas >= 5) {
            salida = salida + "L";
            for (int i = 6; i <= decenas; i++) {
                salida = salida + "X";
            }
        } else if (decenas == 4) {
            salida = salida + "XL";
        } else {
            for (int i = 1; i <= decenas; i++) {
                salida = salida + "X";
            }
        }

        if (centenas == 9) {
            salida = salida + "CM";
        } else if (centenas >= 5) {
            salida = salida + "D";
            for (int i = 6; i <= centenas; i++) {
                salida = salida + "C";
            }
        } else if (centenas == 4) {
            salida = salida + "CD";
        } else {
            for (int i = 1; i <= centenas; i++) {
                salida = salida + "C";
            }
        }

        for (int i = 1; i <= millares; i++) {
            salida = salida + "M";
        }

        return salida;

    }

}
