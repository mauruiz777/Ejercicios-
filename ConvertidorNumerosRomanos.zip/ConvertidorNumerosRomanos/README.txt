Nombre: Mauricio Ruiz Jaramillo
e-mail: mauruiz777@icloud.com

Instrucciones para ejecutar el convertidor de números Romanos.

1.-Ejecuta el programa.
2.-Te pedirá números del 1 al 1000 introduce números dentro de este rango, En caso de que el numero este debajo de este rango o sobre del mismo, volverá a solicitarlo.
3.-una vez que hayas cumplido con el paso dos entonces presiona la tecla ENTER y en una linea nueva aparecerá tu numero el numero que insertaste en notación Romana.
