Nombre:Mauricio Ruiz Jaramillo
e-mail:mauruiz777@icloud.com

Instrucciones para ejecutar Traductor Morse.

1.- Ejecuta el programa.
2.- En consola encontraras un menú el cual requiere que introduzcas un numero que corresponde
a tu elección, el numero 1 es para que puedas traducir texto normal a código Morse, el numero
2 es para traducir de código Morse a texto normal.

	si tu elección fue el numero 1.

	Ingresa el texto que deseas traducir sin comas, puntos, o caracteres especiales y presiona enter para ver el equivalente en código Morse.

	si tu elección fue el numero 2.
	ingresa el código Morse que deseas traducir a texto separados por un espacio después de cada código de cada letra, y las palabras completas por 3 espacios y presiona enter para ver el resultado.

Deberas volver a correr el programa para invertir tu elección o cambiarla.