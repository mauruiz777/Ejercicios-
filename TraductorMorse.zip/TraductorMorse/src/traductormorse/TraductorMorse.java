/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traductormorse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author MauricioRJ
 */
public class TraductorMorse {

    private static String salida = "";

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int eleccion=0;
        try {
             System.out.println("Ingresa el numero que corresponde a tu eleccion:\n 1.- Traduccion de Texto a Codigo Morse\n 2.- Traduccion De  Codigo Morse a Texto");

        Scanner ent = new Scanner(System.in);
        eleccion = ent.nextInt();
            
        } catch (Exception e) {
            System.out.println("Opcion Invalida");
        }
 
        

        if (eleccion == 1) {

            Scanner texto;
            texto = new Scanner(System.in);
            System.out.println("Ingresa el texto que deseas traducir: ");
            String entrada = texto.nextLine().toUpperCase();
            String[] contenido = entrada.split(" ");
            System.out.println("En Codigo Morse es el Siguiente: ");
            for (String palabra : contenido) {
                char[] letras = palabra.toCharArray();

                for (char letra : letras) {

                    salida += traduceDeTextoMorse(letra);

                }
                salida += "  ";
            }
            System.out.println(salida);
        } else {
            if (eleccion == 2) {
                System.out.println("entro de morse a texto");

                Scanner morse;
                morse = new Scanner(System.in);
                System.out.println("Ingresa el Codigo que deseas traducir: ");
                String entrada = morse.nextLine();
                String[] contenido = entrada.split("   ");
                System.out.println("El texto del codigo es el Siguiente: ");
                for (String palabra : contenido) {
                    String[] letras = palabra.split(" ");

                    for (String letra : letras) {
                      
                        salida += traduceDeMorseTexto(letra);

                    }
                    salida += "  ";
                }
                System.out.println(salida);
            }

        }

    }
    
    public static String traduceDeTextoMorse(char letra) {
        String salida = "";
        if (letra == 'A') {
            salida += " .-";

        }
        if (letra == 'B') {
            salida += " -...";
        }
        if (letra == 'C') {
            salida += " -.-.";
        }

        if (letra == 'D') {
            salida += " -..";

        }
        if (letra == 'E') {
            salida += " .";

        }
        if (letra == 'F') {
            salida += " ..-.";

        }
        if (letra == 'G') {
            salida += " --.";

        }
        if (letra == 'H') {
            salida += " ....";

        }
        if (letra == 'I') {
            salida += " ..";

        }
        if (letra == 'J') {
            salida += " .---";

        }
        if (letra == 'K') {
            salida += " -.-";

        }
        if (letra == 'L') {
            salida += " .-..";

        }
        if (letra == 'M') {
            salida += " --";

        }
        if (letra == 'N') {
            salida += " -.";

        }
        if (letra == 'O') {
            salida += " ---";

        }
        if (letra == 'P') {
            salida += " .--.";

        }
        if (letra == 'Q') {
            salida += " --.-";

        }
        if (letra == 'R') {
            salida += " .-.";

        }
        if (letra == 'S') {
            salida += " ...";

        }
        if (letra == 'T') {
            salida += " -";

        }
        if (letra == 'U') {
            salida += " ..-";

        }
        if (letra == 'V') {
            salida += " ...-";

        }
        if (letra == 'W') {
            salida += " .--";

        }
        if (letra == 'X') {
            salida += " -..-";

        }
        if (letra == 'Y') {
            salida += " -.--";

        }
        if (letra == 'Z') {
            salida += " --..";

        }
        if (letra == '1') {
            salida += " .----";

        }
        if (letra == '2') {
            salida += " ..---";

        }
        if (letra == '3') {
            salida += " ...--";

        }
        if (letra == '4') {
            salida += " ....-";

        }
        if (letra == '5') {
            salida += " .....";

        }
        if (letra == '6') {
            salida += " -....";

        }
        if (letra == '7') {
            salida += " --...";

        }
        if (letra == '8') {
            salida += " ---..";

        }
        if (letra == '9') {
            salida += " ----.";

        }
        if (letra == '0') {
            salida += " -----";

        }

        return salida;
    }

    public static String traduceDeMorseTexto(String morse) {
      
        String salida = "";

        if (morse.equals(".-")) {
            salida += "A";
        }
        if (morse.equals("-...")) {
            salida += "B";
        }
        if (morse.equals("-.-.")) {
            salida += "C";
        }
        if (morse.equals("-..")) {
            salida += "D";
        }
        if (morse.equals(".")) {
            salida += "E";
        }
        if (morse.equals("..-.")) {
            salida += "F";
        }
        if (morse.equals("--.")) {
            salida += "G";
        }
        if (morse.equals("....")) {
            salida += "H";
        }
        if (morse.equals("..")) {
            salida += "I";
        }
        if (morse.equals(".---")) {
            salida += "J";
        }
        if (morse.equals("-.-")) {
            salida += "K";
        }
        if (morse.equals(".-..")) {
            salida += "L";
        }
        if (morse.equals("--")) {
            salida += "M";
        }
        if (morse.equals("-.")) {
            salida += "N";
        }
        if (morse.equals("---")) {
            salida += "O";
        }
        if (morse.equals(".--.")) {
            salida += "P";
        }
        if (morse.equals("--.-")) {
            salida += "Q";
        }
        if (morse.equals(".-.")) {
            salida += "R";
        }
        if (morse.equals("...")) {
            salida += "S";
        }
        if (morse.equals("-")) {
            salida += "T";
        }
        if (morse.equals("..-")) {
            salida += "U";
        }
        if (morse.equals("...-")) {
            salida += "V";
            ;
        }
        if (morse.equals(".--")) {
            salida += "W";
        }
        if (morse.equals("-.--")) {
            salida += "Y";
        }
        if (morse.equals("--..")) {
            salida += "Z";
        }
        if (morse.equals(".----")) {
            salida += "1";
        }
        if (morse.equals("..---")) {
            salida += "2";
        }
        if (morse.equals("...--")) {
            salida += "3";
        }
        if (morse.equals("....-")) {
            salida += "4";
        }
        if (morse.equals("-....")) {
            salida += "5";
        }
        if (morse.equals("-....")) {
            salida += "6";
        }
        if (morse.equals("--...")) {
            salida += "7";
        }
        if (morse.equals("---..")) {
            salida += "8";
        }
        if (morse.equals("----.")) {
            salida += "9";
        }
        if (morse.equals("-----")) {
            salida += "0";
        }
        return salida;
    }

}
