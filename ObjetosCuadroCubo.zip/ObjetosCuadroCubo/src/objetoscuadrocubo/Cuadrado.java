/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetoscuadrocubo;

/**
 *
 * @author MauricioRJ
 */
public class Cuadrado {

    public Cuadrado(float lado) {
        
        this.lado=lado;
    }
    
    
    
    protected  float lado;

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }
    
    public float area(){
        float area=lado*lado;
        return area;
    }
    
    public double perimetro(){
        float perimetro=lado*4;
        return perimetro;
    }
}
