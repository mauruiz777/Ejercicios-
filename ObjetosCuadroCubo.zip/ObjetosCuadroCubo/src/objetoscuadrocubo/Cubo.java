/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetoscuadrocubo;

import static java.lang.Math.pow;

/**
 *
 * @author MauricioRJ
 */
public class Cubo extends Cuadrado{

    public Cubo(float lado) {
        super(lado);
    }
    
    public double volumen(){
        double volumen=(double) pow(lado,3);
        return volumen;
    }

    @Override
    public double perimetro() {
        double perimetro=lado*12;
        return perimetro; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
