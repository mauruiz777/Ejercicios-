/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetoscuadrocubo;

import java.util.Scanner;

/**
 *
 * @author MauricioRJ
 */
public class ObjetosCuadroCubo {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        System.out.println("Ingresa  un lado del cuadrado");
        Scanner entrada = new Scanner(System.in);
        float lado = entrada.nextInt();
        int opcion;
        do{
            System.out.println("SE ESTA CALCULADO CON UN LADO DE MEDIDA: "+lado);
        System.out.println("Elije la opcion digitando el numero de lo que deseas calcular:\n "
                + "1.-Calcular el area del cuadrado\n"
                + " 2.-Calcular el perimetro del Cuadrado\n"
                + " 3.-Calcular el volumen del cubo\n"
                + " 4.-Calcular el perimetro del cubo\n"
                + " 5.-Nuevo calculo\n"
                + " 6.-Salir");

        opcion = entrada.nextInt();
        Cuadrado cuadrado=new Cuadrado(lado);
        Cubo cubo=new Cubo(lado);
        switch (opcion) {
            
            case 1:
                
               float  area=cuadrado.area();
                System.out.println("El area del cuadrado es: "+area);
             break;
             
             case 2:
               
               double  perimetro=cuadrado.perimetro();
               System.out.println("El perimetro del cuadrado es: "+perimetro);
                
             break;
             
             case 3:
                 double  volumen=cubo.volumen();
                System.out.println("El volumen del cuadrado es: "+volumen);
                
             break;
             
             case 4:
                double  perimet=cubo.perimetro();
                System.out.println("El volumen del cuadrado es: "+perimet);
             break;
             
             case 5:
                 System.out.println("Ingresa  un lado del cuadrado");
                 lado=entrada.nextFloat();
                
             break;
             
             case 6:
                
             break;
             
             
             
        }
        }while(opcion!=6);
    }

}
