Nombre: Mauricio Ruiz Jaramillo
e-mail: mauruiz777@icloud.com

Instrucciones para ejecutar el convertidor de números Romanos.

1.-Ejecuta el programa.
2.-Como primera entrada te pide el lado del cuadrado que se va calcular, al tratarse de un cuadrado y un cubo todos los lados son iguales, solo necesitas ingresar un numero.
3.-Elige la opción de lo que deseas calcular ingresando el numero que corresponde a tu opción.
4.- Si deseas hacer cálculos con un valor diferente ingresa el numero 5 este volverá a pedirte el valor del lado para calcular.
5.-para salir del programa solo ingresa el numero 6 una vez terminado los cálculos.
